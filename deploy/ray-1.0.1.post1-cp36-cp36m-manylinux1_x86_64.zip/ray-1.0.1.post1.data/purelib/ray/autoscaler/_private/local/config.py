def bootstrap_local(config):
    return config
