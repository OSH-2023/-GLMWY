log_prefix = "StaroidNodeProvider: "
