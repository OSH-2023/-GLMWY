from ray.util import multiprocessing


class Pool(multiprocessing.Pool):
    pass  # moved to util package
