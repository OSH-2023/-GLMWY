from ray.rllib.agents.a3c.a3c import A3CTrainer, DEFAULT_CONFIG
from ray.rllib.agents.a3c.a2c import A2CTrainer

__all__ = ["A2CTrainer", "A3CTrainer", "DEFAULT_CONFIG"]
